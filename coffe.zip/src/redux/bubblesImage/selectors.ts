
import { RootState } from "../index";

export const geUsersBubbles = (state: RootState) => state.bubblesImage.users;



