
export type bubblesImageSliceState = {
    users: Array<users>,
}
 

export type users = {
    users: any
    id: string,
    avatar: string,
}