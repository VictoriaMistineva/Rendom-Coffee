
import { RootState } from "../index";

export const getitems = (state: RootState) => state.secondPage.items;



