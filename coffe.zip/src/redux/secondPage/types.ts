export type SecondPageSliceState = {
    items: any,
}
