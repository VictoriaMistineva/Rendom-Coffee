export type YourLocationPageSliceState = {
    "city": string;
    "cities": Array<string>;
}
