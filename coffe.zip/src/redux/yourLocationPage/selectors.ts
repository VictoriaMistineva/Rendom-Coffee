
import { RootState } from "../index";

export const getCity = (state: RootState) => state.yourLocationPage.city;
export const getCities = (state: RootState) => state.yourLocationPage.cities;



