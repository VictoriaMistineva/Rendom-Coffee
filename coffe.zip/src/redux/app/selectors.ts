import { RootState } from "../index";

export const getIsBlur = (state : RootState) => state.app.isBlur;