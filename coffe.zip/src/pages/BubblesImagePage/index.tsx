import React from 'react';
import { useSelector } from 'react-redux';
import Bubbles from '../../components/Bubbles/Bubbles';
import NewBubbles from '../../components/Bubbles/NewBubbles';
import FlowerBubble from '../../components/FlowerBubble';

const BubblesImagePage = () => {
    return ( 
        <>
            {/* <Bubbles /> */}
            <NewBubbles/>
            {/* <FlowerBubble/> */}
        </>
    );
};

export default BubblesImagePage;
    
