import React from 'react';
import "./styles.css";
const FlowerBubble = () => {
    return (
        <>
            <div className="path">
                    <img src="http://lea.verou.me/book/adamcatlace.jpg" className="avatar" />
                    <img src="http://lea.verou.me/book/adamcatlace.jpg" className="avatar" />
                    <img src="http://lea.verou.me/book/adamcatlace.jpg" className="avatar" />
                    <img src="http://lea.verou.me/book/adamcatlace.jpg" className="avatar" />
                    <img src="http://lea.verou.me/book/adamcatlace.jpg" className="avatar" />
                    <img src="http://lea.verou.me/book/adamcatlace.jpg" className="avatar" />
                    <img src="http://lea.verou.me/book/adamcatlace.jpg" className="avatar" />
                    <img src="http://lea.verou.me/book/adamcatlace.jpg" className="avatar" />
                    <img src="http://lea.verou.me/book/adamcatlace.jpg" className="avatar" />
                    <img src="http://lea.verou.me/book/adamcatlace.jpg" className="avatar" />
            </div>
        </>
    );
};

export default FlowerBubble;
