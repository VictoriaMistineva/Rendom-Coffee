import React from 'react';
import { Container, Row, Col } from 'react-grid-system';
import { data } from "./data";
import "./styles.css";
import FlowerBubble from '../FlowerBubble';
import { useSelector } from 'react-redux';
import { geUsersBubbles } from '../../redux/bubblesImage';
import { Button } from '@salutejs/plasma-ui';

const NewBubbles = () => {
    const containerWidth = window.innerWidth < 650 ? window.innerWidth : 500;
    const startBubbleWidth = Math.floor(containerWidth / 5);
    const users = useSelector(geUsersBubbles);

    type BubbleImageProps = {
        imgUrl: string;
        width: number;
        visibility?: boolean;
        top?: number;
        right?: number;
        left?: number;
        bottom?: number;
    };

    const BubbleImage: React.FC<BubbleImageProps & React.HTMLAttributes<HTMLImageElement>> = ({ imgUrl, width, visibility, top, right, left, bottom }) => {
        return (
            <>
                <img src={imgUrl} width={width} style={{
                    borderRadius: "50%",
                    top: top ? top : 0,
                    right: right ? right : 0,
                    left: left ? left : 0,
                    bottom: bottom ? bottom : 0,
                    position: "relative",
                    animationDuration: "7s",
                    visibility: visibility === false ? "hidden" : "visible",
                }}
                    //className={"bubbleImg5"}
                    className={"bubbleImg5"}
                />
            </>
        );
    };
    
    return (
        <>
            <Container fluid >
                <Row justify="around">
                    <Col xs={"content"} style={{ marginTop: 30 }}>
                        <BubbleImage
                            imgUrl={users[0] ? users[0].avatar : ""}
                            width={startBubbleWidth}
                        />
                    </Col>
                    <Col xs={"content"} >
                        <BubbleImage
                            imgUrl={users[1] ? users[1].avatar : ""}
                            width={startBubbleWidth}
                        />
                    </Col>
                    <Col xs={"content"} style={{ marginTop: 30 }}>
                        <BubbleImage
                            imgUrl={users[2] ? users[2].avatar : ""}
                            width={startBubbleWidth}
                        />
                    </Col>
                </Row>
                <br></br>
                <Row justify="around" style={{ marginTop: 30 }}>
                    <Col className={"bubbleImg6"}
                        style={{
                            animationDuration: "11s"
                        }}>
                        <FlowerBubble />
                    </Col>
                </Row>

                <Row justify="around" style={{ marginTop: 230 }}>
                    <Col xs={"content"}>
                        <BubbleImage
                            imgUrl={users[10] ? users[11].avatar : ""}
                            width={startBubbleWidth}
                        />
                    </Col>
                    <Col xs={"content"} style={{ marginTop: 20 }}>
                        <BubbleImage
                            imgUrl={users[12] ? users[12].avatar : ""}
                            width={startBubbleWidth}
                        />
                    </Col>
                    <Col xs={"content"}>
                        <BubbleImage
                            imgUrl={users[13] ? users[5].avatar : ""}
                            width={startBubbleWidth}
                        />
                    </Col>
                </Row>
                <br></br>
                <Row justify="around" >
                    <Col xs={"content"}>
                        <BubbleImage
                            imgUrl={users[14] ? users[14].avatar : ""}
                            width={startBubbleWidth}
                            top={-15}
                            left={30}
                        />
                    </Col>
                    <Col xs={"content"}>
                        <BubbleImage
                            imgUrl={users[15] ? users[15].avatar : ""}
                            width={startBubbleWidth}
                            top={-15}
                            left={-30}
                        />
                    </Col>
                </Row>

                {/* test */}
                <Row justify="around" >
                    <Col xs={"content"}>
                        <BubbleImage
                            imgUrl={users[16] ? users[17].avatar : ""}
                            width={startBubbleWidth}
                        />
                    </Col>
                    <Col xs={"content"} style={{ marginTop: 20 }}>
                        <BubbleImage
                            imgUrl={users[17] ? users[17].avatar : ""}
                            width={startBubbleWidth}

                        />
                    </Col>
                    <Col xs={"content"}>
                        <BubbleImage
                            imgUrl={users[18] ? users[18].avatar : ""}
                            width={startBubbleWidth}
                        />
                    </Col>
                </Row>
                <br></br>
                <Row justify="around" >
                    <Col xs={"content"}>
                        <BubbleImage
                            imgUrl={users[19] ? users[19].avatar : ""}
                            width={startBubbleWidth}
                            top={-15}
                            left={30}
                        />
                    </Col>
                    <Col xs={"content"}>
                        <BubbleImage
                            imgUrl={users[20] ? users[20].avatar : ""}
                            width={startBubbleWidth}
                            top={-15}
                            left={-30}
                        />
                    </Col>
                </Row>
                <Row justify="around" >
                    <Col xs={"content"}>
                        <BubbleImage
                            imgUrl={users[21] ? users[21].avatar : ""}
                            width={startBubbleWidth}
                        />
                    </Col>
                    <Col xs={"content"} style={{ marginTop: 20 }}>
                        <BubbleImage
                            imgUrl={users[22] ? users[22].avatar : ""}
                            width={startBubbleWidth}

                        />
                    </Col>
                    <Col xs={"content"}>
                        <BubbleImage
                            imgUrl={users[23] ? users[23].avatar : ""}
                            width={startBubbleWidth}
                        />
                    </Col>
                </Row>
                <br></br>
                <Row justify="around" >
                    <Col xs={"content"}>
                        <BubbleImage
                            imgUrl={users[24] ? users[24].avatar : ""}
                            width={startBubbleWidth}
                            top={-15}
                            left={30}
                        />
                    </Col>
                    <Col xs={"content"}>
                        <BubbleImage
                            imgUrl={users[25] ? users[25].avatar : ""}
                            width={startBubbleWidth}
                            top={-15}
                            left={-30}
                        />
                    </Col>
                </Row>
            </Container>
        </>
    );
};

export default NewBubbles;