import React from 'react';
import "./styles.css";
import { useDispatch, useSelector } from 'react-redux';
import { sendData } from '../../redux/assistant';
import { geUsersBubbles } from '../../redux/bubblesImage';

const FlowerBubble = (item: any) => {
    const dispatch = useDispatch();
    const users = useSelector(geUsersBubbles);
    const handleClickButton = (id: string) => {
        // console.log(item);
        // dispatch(
        //   sendData({
        //     action_id: 'Back',
        //     parameters: id
        //   })
        // );
    }
    const arr = () => {
        const newArray = [];

        for (let i = 2; i <= 9 && i < users.length; i++) {
            newArray.push(users[i]);
        }
        return newArray;
    }
    return (
        <div className="container">
            <div className="path">
                <div className="imgCenter">
                    <img src="http://lea.verou.me/book/adamcatlace.jpg" className="avatar2" alt="description of image" />
                </div>
                {arr().map((item, index) => (
                    <div className="avatarContainer" onClick={() => handleClickButton(item.id)}>
                        <img src={item.avatar} className="avatar" alt="description of image" />
                    </div>
                ))
                }
            </div>
        </div>
    );
};

export default FlowerBubble;
