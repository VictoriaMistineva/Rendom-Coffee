const w = 80;

export type BubbleAppearanceOptions = {
    imgUrl: string,
    width: number,
}

export const data : Array<BubbleAppearanceOptions> = [
    // {
    //     imgUrl: "",
    //     width: w,
    // },
    // {
    //     imgUrl: "",
    //     width: w,
    // },
    {
        imgUrl: "https://i.pravatar.cc/?img=3",
        width: w,
    },
    {
        imgUrl: "https://i.pravatar.cc/?img=4",
        width: w,
    },
    {
        imgUrl: "https://i.pravatar.cc/?img=5",
        width: w,
    },
    {
        imgUrl: "https://i.pravatar.cc/?img=6",
        width: w,
    },
    {
        imgUrl: "https://i.pravatar.cc/?img=7",
        width: w,
    },
    {
        imgUrl: "https://i.pravatar.cc/?img=8",
        width: w,
    },
    {
        imgUrl: "https://i.pravatar.cc/?img=9",
        width: w,
    },
    {
        imgUrl: "https://i.pravatar.cc/?img=19",
        width: w,
    },
    {
        imgUrl: "https://i.pravatar.cc/?img=29",
        width: w,
    },
    {
        imgUrl: "https://i.pravatar.cc/?img=30",
        width: w,
    },
    {
        imgUrl: "https://i.pravatar.cc/?img=33",
        width: w,
    },
    {
        imgUrl: "https://i.pravatar.cc/?img=31",
        width: w,
    },
    {
        imgUrl: "https://i.pravatar.cc/?img=32",
        width: w,
    },
    {
        imgUrl: "https://i.pravatar.cc/?img=34",
        width: w,
    },
    {
        imgUrl: "https://i.pravatar.cc/?img=35",
        width: w,
    },
    {
        imgUrl: "https://i.pravatar.cc/?img=36",
        width: w,
    },
    {
        imgUrl: "https://i.pravatar.cc/?img=37",
        width: w,
    },
    {
        imgUrl: "https://i.pravatar.cc/?img=38",
        width: w,
    }
];
