
export type bubblesImageSliceState = {
    users: Array<users>,
}
 

export type users = {
    id: string,
    avatar: string,
}