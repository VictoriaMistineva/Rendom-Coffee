
import { RootState } from "../index";

export const geUsers = (state: RootState) => state.bubblesImage.users;



