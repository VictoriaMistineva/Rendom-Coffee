export type MainPageSliceState = {
    items: any,
    isMicrophoneOff: boolean,
    isSoundOff: boolean,
}
