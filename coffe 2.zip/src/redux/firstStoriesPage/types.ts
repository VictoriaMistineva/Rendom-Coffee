export type StartConfirmationPageSliceState = {
    access: boolean,
    checkboxAccess: boolean,
}
