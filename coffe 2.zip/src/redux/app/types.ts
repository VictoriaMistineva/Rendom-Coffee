export type AppSliceState = {
    isBlur: boolean,
}