import { RootState } from "../index";

export const getMethods =  (state: RootState) => state.selectionMethod.methods;

