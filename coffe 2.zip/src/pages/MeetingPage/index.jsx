/* eslint-disable */
import React, { useCallback, useEffect, useMemo } from 'react';
import cn from 'classnames';
import { useSelector, useDispatch } from 'react-redux';
import { IconChevronLeft } from '@salutejs/plasma-icons';
import { ReactComponent as IconClock } from '../../assets/img/icons/clock.svg';
import { ReactComponent as IconPerson } from '../../assets/img/icons/person.svg';
import { ReactComponent as IconNotAccepted } from '../../assets/img/icons/ne_priniato.svg';
import { ReactComponent as IconAccepted } from '../../assets/img/icons/soglasovano.svg';
import { ReactComponent as IconQuestion } from '../../assets/img/icons/pod_voprosom.svg';
import { ReactComponent as IconParticipants } from '../../assets/img/icons/uchastniki.svg';
import { ReactComponent as IconConflict } from '../../assets/img/icons/peresechenie.svg';
import { ReactComponent as IconHouse } from '../../assets/img/icons/house.svg';
import { ReactComponent as IconTach } from '../../assets/img/icons/tach.svg';
import { ReactComponent as IconEarth } from '../../assets/img/icons/earth.svg';
import { ReactComponent as IconBell } from '../../assets/img/icons/bell.svg';

import styles from './MeetingPage.module.scss';

const MeetingPage = () => {
  const dispatch = useDispatch();

  return (
      <>
        <div className={cn(styles.eventPage, isBlur && styles.eventPage_blur)}>
          <div
            className={cn(
              styles.eventPage__section,
              styles.eventPage__section_main
            )}
          >
            <div className={styles.eventPage__rightColumnSection}>
              {/* <div
                className={cn(styles.eventPage__statusMeet, {
                  [styles.eventPage__statusMeet_accept]:
                    !isConflicting &&
                    ['accepted', 'question', 'organizer'].includes(status),
                  [styles.eventPage__statusMeet_missed]:
                    !isConflicting && status === 'notAccepted',
                  [styles.eventPage__statusMeet_intersecting]: isConflicting,
                })}
              /> */}
              <div className={styles.eventPage__icon}>
                <IconClock className={styles.eventPage__iconPoint} />
              </div>
              <div className={styles.eventPage__sectionTimeInfo}>
                <div
                  className={cn(
                    styles.eventPage__text,
                    styles.eventPage__darkerText
                  )}
                >
                  {getDateMeetInfo(date)}
                </div>
                <div
                  className={cn(
                    styles.eventPage__text,
                    styles.eventPage__darkerText
                  )}
                >
                  {start} - {end}
                </div>
              </div>
            </div>
          </div>
          {/* <div
            className={cn(
              styles.eventPage__section,
              styles.eventPage__section_center
            )}
          >
            <div className={styles.eventPage__icon}>
              {status === 'notAccepted' && (
                <IconNotAccepted className={styles.eventPage__iconPoint} />
              )}
              {['accepted', 'organizer'].includes(status) && (
                <IconAccepted className={styles.eventPage__iconPoint} />
              )}
              {status === 'question' && (
                <IconQuestion className={styles.eventPage__iconPoint} />
              )}
            </div>
            <div
              className={cn(
                styles.eventPage__text,
                styles.eventPage__darkerText,
                styles.eventPage__text_full
              )}
            >
              {([
                'не принято',
                'нет ответа',
                'отклонено',
                'ответ не получен',
              ].includes(response) &&
                'Не принято') ||
                (['принято', 'организатор встречи'].includes(response) &&
                  'Принято') ||
                'Под вопросом'}
            </div>
          </div> */}


            {/* преговорка */}
          {locations !== ' ' && (
            <button
              className={cn(
                styles.eventPage__section,
                styles.eventPage__section_center,
                styles.eventPage__section_button
              )}
            >
              <div
                className={cn(styles.eventPage__icon, styles.eventPage__icon_m)}
              >
                <IconHouse className={styles.eventPage__iconPoint} />
              </div>
              <div
                className={cn(
                  styles.eventPage__text,
                  styles.eventPage__text_full,
                  styles.eventPage__text_main
                )}
              >
                Переговорка{' '}
                <span className={styles.eventPage__darkerText}>{locations}</span>
                <IconChevronLeft className={styles.eventPage__arrow} />
              </div>
            </button>
          )}
          {meetingLink && (
            <button
              className={cn(
                styles.eventPage__section,
                styles.eventPage__section_center,
                styles.eventPage__section_button
              )}
            >
              <div
                className={cn(styles.eventPage__icon, styles.eventPage__icon_m)}
              >
                <IconEarth className={styles.eventPage__iconPoint} />
              </div>
              <div
                className={cn(
                  styles.eventPage__text,
                  styles.eventPage__text_full,
                  styles.eventPage__text_main
                )}
              >
                {meetingTitle}{' '}
                <span className={styles.eventPage__darkerText}>
                  {meetingLink}
                </span>
                <IconChevronLeft className={styles.eventPage__arrow} />
              </div>
            </button>
          )}
          {/* Напоминание  */}
          <button
            disabled
            className={cn(
              styles.eventPage__section,
              styles.eventPage__section_center,
              styles.eventPage__section_button
            )}
          >
            <div className={styles.eventPage__icon}>
              <IconBell className={styles.eventPage__iconPoint} />
            </div>
            <div
              className={cn(styles.eventPage__text, styles.eventPage__text_full)}
            >
              <div
                className={cn(
                  styles.eventPage__text_main,
                  styles.eventPage__darkerText
                )}
              >
                Напоминание (скоро)
                <IconChevronLeft className={styles.eventPage__arrow} />
              </div>
              <div className={styles.eventPage__darkerText}>
                За 5 минут, за 10 минут, за 2 дня
              </div>
            </div>
          </button>

          {requiredAttendees.length !== 0 && (
            <button
              className={cn(
                styles.eventPage__section,
                styles.eventPage__section_button
              )}
            >
              <div
                className={cn(styles.eventPage__icon, styles.eventPage__icon_m)}
              >
                <IconParticipants className={styles.eventPage__iconPoint} />
              </div>
              <div
                className={cn(
                  styles.eventPage__text,
                  styles.eventPage__text_full
                )}
              >
                <div className={styles.eventPage__text_main}>
                  Участники{' '}
                  <IconChevronLeft className={styles.eventPage__arrow} />
                </div>
                <div className={styles.eventPage__darkerText}>
                  {requiredAttendees
                    .slice(0, 3)
                    .map((el) => el.mailboxUser.name)
                    .join(', ')}
                  {attendeesCount > 3 &&
                    `, и еще ${attendeesCount - 3}`}
                </div>
              </div>
            </button>
          )}
        </div>
      </>
  );
};

export default MeetingPage;
