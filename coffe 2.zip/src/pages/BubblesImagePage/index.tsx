import React from 'react';
import { useSelector } from 'react-redux';
import Bubbles from '../../components/Bubbles/Bubbles';

const BubblesImagePage = () => {
    return (
        <>
            <Bubbles />
        </>
    );
};

export default BubblesImagePage;
    
